<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title mb-0">
            FORM UPLOAD EXCEL ANGGARAN KAS
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form id="form-ubah">
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="tahun">Tahun</label>
                        <input type="hidden" name="id_no" value="<?= $tbl_dana_dekon['id_dana'] ?>">
                        <input type="text" name="tahun" id="tahun" class="form-control" value="<?= $tbl_dana_dekon['tahun']; ?>" readonly>
                        <small class="text-danger tahun"></small>
                    </div>
                    <div class="form-group">
                        <label for="kd_satker">KD Satker</label>
                        <input type="text" name="kd_satker" id="kd_satker" value="<?= $tbl_dana_dekon['kd_satker'] ?>" class="form-control">
                        <small class="text-danger kd_satker"></small>
                    </div>
                    <div class="form-group">
                        <label for="pagu">Pagu</label>
                        <input type="text" name="pagu" id="pagu" value="<?= $tbl_dana_dekon['pagu'] ?>" class="form-control">
                        <small class="text-danger pagu"></small>
                    </div>
                    <div class="form-group">
                        <label for="keterangan">Keterangan</label>
                        <input type="text" name="keterangan" id="keterangan" value="<?= $tbl_dana_dekon['keterangan'] ?>" class="form-control" autocomplete="off">
                        <small class="text-danger keterangan"></small>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" id="btn-upload" class="btn btn-sm btn-primary">
                <i class="fa fa-save"></i> SIMPAN
            </button>
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">
                <i class="fa fa-times"></i> BATAL
            </button>
        </div>
    </form>
</div>

<script>
    $('.select2').select2();
</script>