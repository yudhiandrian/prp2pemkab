<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title mb-0">
            FORM UBAH
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form id="form-ubah">
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="jenis_pelaksanaan">Jenis Pelaksanaan</label>
                        <input type="hidden" name="id_jenis_pelaksanaan" id="id_jenis_pelaksanaan" value="<?= $jenis['id_jenis_pelaksanaan']; ?>" class="form-control" autocomplete="off">
                        <input type="text" name="jenis_pelaksanaan" id="jenis_pelaksanaan" value="<?= $jenis['nama_jenis_pelaksanaan']; ?>" class="form-control" autocomplete="off">
                        <small class="text-danger jenis_pelaksanaan"></small>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" id="btn-ubah" class="btn btn-sm btn-primary">
                <i class="fa fa-save"></i> SIMPAN
            </button>
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">
                <i class="fa fa-times"></i> BATAL
            </button>
        </div>
    </form>
</div>