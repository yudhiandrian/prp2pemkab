<?php $this->load->view("_partial/header"); ?>
<div class="panel-header bg-primary-gradient">
    <div class="page-inner py-4">
        <div class="d-flex align-items-left flex-column flex-sm-row">
            <h3 class="text-white pb-3 fw-bold">Tampilan Aplikasi</h3>
            <div class="ml-sm-auto py-md-0">
                <button type="button" id="tombol-ubah" class="btn btn-success btn-round btn mr-2 mb-3" data-toggle="modal" data-target="#modal-form-action"> <i class="fa fa-edit"> Edit</i></button>
            </div>
        </div>
    </div>
</div>

<div class="page-inner mt--5">
    <div class="card full-height">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12">
                    <fieldset class="scheduler-border">
                        <legend class="scheduler-border">Tampilan Aplikasi</legend>
                        <div class="preload_tampilan" style="width: 100%; text-align: center; border: 1px solid #00a65a; border-radius: 25px;">
                            <img src="<?= base_url('images/ring_green.gif') ?>" alt="" style="width: 125px;">
                            <h5>Sedang memuat data...</h5>
                        </div>
                        <div id="load-tampilan" style="display: none;"></div>
                    </fieldset>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal-form-action" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div id="load-form-action"></div>
    </div>
</div>

<div class="modal fade" id="modal-foto" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div id="load-form-foto"></div>
    </div>
</div>

<?php $this->load->view('_partial/footer'); ?>
<script>
    $(document).ready(function() {
        load_data_rekap();
    });

    function load_data_rekap() {
            $('#load-tampilan').css('display', 'none');
            $('.preload_tampilan').show();
            $.ajax({
                url: '<?= site_url('tampilan-aplikasi/load'); ?>',
                type: "POST",
                dataType: "html",
                success: function(data) {
                    $('#load-tampilan').css('display', 'block');
                    $('.preload_tampilan').hide();
                    $('#load-tampilan').html(data);
                }
            });
        };

    $(document).on("click", "#tombol-ubah", function() {
        var self = this;
        $(self).attr('disabled', true);
        $(self).html("<i class='fa fa-circle-notch fa-spin fa-sm'></i>");
        $.ajax({
            url: '<?= site_url('tampilan-aplikasi/form'); ?>',
            type: "POST",
            data: {
                opsi: "edit",
                id: $(this).data('id')
            },
            success: function(data) {
                $('#load-form-action').html(data);
                $(self).html('<i class="fa fa-edit"> Edit</i>');
                $(self).attr('disabled', false);
            }
        });
    });

    $(document).on("submit", "#form-ubah", function(e) {
        e.preventDefault(e);
        var self = "#btn-ubah";
        var form_id = "#form-ubah";
        $(self).attr('disabled', true);
        $(self).html("<i class='fa fa-circle-notch fa-spin fa-sm'></i> LOADING...");
        $.ajax({
            url: "<?= site_url('tampilan-aplikasi/edit'); ?>",
            type: 'POST',
            data: $(form_id).serialize(),
            dataType: "json",
            success: function(data) {
                if (data.status) {
                    $('#modal-form-action').modal('hide');
                    load_data_rekap();
                    if (data.notif) {
                        notifikasi('success', 'Berhasil', 'Data Berhasil Disimpan');
                    } else {
                        notifikasi('error', 'Gagal', 'Data Gagal Disimpan');
                    }
                } else {
                    notifikasi('error', 'Gagal', data.pesan);
                    $.each(data.errors, function(key, value) {
                        $(form_id + ' [name="' + key + '"]').parents(".form-group").removeClass('has-success');
                        $(form_id + ' [name="' + key + '"]').parents(".form-group").addClass('has-error');
                        $(form_id + ' .' + key).html(value);
                        if (value == "") {
                            $(form_id + ' [name="' + key + '"]').parents(".form-group").removeClass('has-error');
                            $(form_id + ' [name="' + key + '"]').parents(".form-group").addClass('has-success');
                        }
                    });
                }
                $(self).html("<i class='fa fa-save'></i> SIMPAN");
                $(self).attr('disabled', false);
            },
            error: function(xhr, status, msg) {
                alert('Status: ' + status + "\n" + msg);
                $(self).html("<i class='fa fa-save'></i> SIMPAN");
                $(self).attr('disabled', false);
            }
        });
    });

    $(document).on("click", "#tombol-foto", function() {
        url = "<?= site_url('tampilan-aplikasi/form'); ?>";
        id = $(this).data('id');
        icon_tombol = '<i class="fa fa-edit"></i> Gambar';
        load_form(url, id, "gambar", "#load-form-foto", "#tombol-foto", icon_tombol);
    });

    $(document).on("submit", "#form-upload", function(e) {
        e.preventDefault(e);
        var self = "#btn-upload";
        var form_id = "#form-upload";
        $(self).attr('disabled', true);
        $(self).html("<i class='fa fa-circle-notch fa-spin fa-sm'></i> LOADING...");
        $.ajax({
            url: "<?= site_url('tampilan-aplikasi/edit_foto'); ?>",
            type: "POST",
            enctype: 'multipart/form-data',
            data: new FormData($(form_id)[0]),
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data.status) {
                    $('#modal-foto').modal('hide');
                    load_data_rekap();
                    if (data.notif) {
                        notifikasi('success', 'Berhasil', 'Data Berhasil Disimpan');
                    } else {
                        notifikasi('error', 'Gagal', 'Data Gagal Disimpan');
                    }
                } else {
                    notifikasi('error', 'Gagal', data.pesan);
                    $.each(data.errors, function(key, value) {
                        $(form_id + ' [name="' + key + '"]').parents(".form-group").removeClass('has-success');
                        $(form_id + ' [name="' + key + '"]').parents(".form-group").addClass('has-error');
                        $(form_id + ' .' + key).html(value);
                        if (value == "") {
                            $(form_id + ' [name="' + key + '"]').parents(".form-group").removeClass('has-error');
                            $(form_id + ' [name="' + key + '"]').parents(".form-group").addClass('has-success');
                        }
                    });
                }
                $(self).html("<i class='fa fa-save'></i> SIMPAN");
                $(self).attr('disabled', false);
            },
            error: function(xhr, status, msg) {
                alert('Status: ' + status + "\n" + msg);
                $(self).html("<i class='fa fa-save'></i> SIMPAN");
                $(self).attr('disabled', false);
            }
        });
    });
</script>
<?php $this->load->view('_partial/tag_close'); ?>