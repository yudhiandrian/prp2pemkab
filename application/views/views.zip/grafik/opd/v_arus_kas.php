<div class="card-body bg-primary">
    <div class="inner">
        <h2 style="color: white; font-weight: bold;"> <i class="fa fa-chart-bar"></i><i class="fa fa-chart-bar"></i> Arus Kas Pada <?=$nama_skpd_tampil?></h2>
        <div class="row">
            <div class="col-lg-7 col-12">
                <div id="arus-kas-bulan" style="width:100%; height: 450px;"></div>
            </div>
            <div class="col-lg-5 col-12">
                <div id="arus-kas-triwulan" style="width:100%; height: 450px;"></div>
            </div>
        </div>
    </div> 
    <br>
</div> 