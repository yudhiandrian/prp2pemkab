<div class="card-body bg-primary-gradient">
    <div class="inner">
        <h2 style="color: white; font-weight: bold;"> <i class="fa fa-chart-bar"></i> Realisasi Belanja SKPD 45 s.d 50 Persen</h2>
        <div id="realisasi-belanja-warning-provinsi" style="width:100%; height: 600px;"></div>
    </div>
    <table class="table table-hover">
    </table>