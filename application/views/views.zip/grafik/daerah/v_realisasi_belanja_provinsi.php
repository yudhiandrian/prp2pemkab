<div class="card-body bg-primary-gradient">
    <div class="inner">
        <h2 style="color: white; font-weight: bold;"> <i class="fa fa-chart-bar"></i> Rating Persen Realisasi Belanja OPD  Pada APBD <?=$nama_kabupaten?></h2>
        <div id="realisasi-belanja-provinsi" style="width:100%; height: 1000px;"></div>
    </div>
    <table class="table table-hover">
    </table>