<div class="card-body bg-primary-gradient">
    <div class="inner">
        <h2 style="color: white; font-weight: bold;"> <i class="fa fa-chart-bar"></i><i class="fa fa-chart-bar"></i> Arus Kas Pada APBD <?=$nama_kabupaten?></h2>
        <div class="row">
            <div class="col-lg-6 col-12">
                <div id="arus-kas-bulanan" style="width:100%; height: 400px;"></div>
            </div>
            <div class="col-lg-6 col-12">
                <div id="arus-kas-triwulan" style="width:100%; height: 400px;"></div>
            </div>
        </div>
    </div>
    <br>
</div> 
