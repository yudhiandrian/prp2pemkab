<div class="card-body bg-primary-gradient">
    <div class="inner">
        <h2 style="color: white; font-weight: bold;"> <i class="fa fa-chart-bar"></i> Realisasi Belanja SKPD di bawah 45 Persen</h2>
        <div id="realisasi-belanja-danger-provinsi" style="width:100%; height: 600px;"></div>
    </div>
    <table class="table table-hover">
    </table>